import ajax from './ajax.js'

export const reqTable=()=>ajax('/dongTaiBiaoTou')


