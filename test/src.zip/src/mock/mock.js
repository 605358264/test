//引入MOCK
import Mock from 'mockjs';
//引入数据
import data from './data.json';
console.log('----------123-----');



Mock.mock('/dongTaiBiaoTou',{code:0,data:data.table
})


