
//初始化状态
export default ({
  table:{},

})
